from aiogram.fsm.state import State, StatesGroup


class Mailing(StatesGroup):
    get_text = State()


class ContentTypeSt(StatesGroup):
    ct = State()
    ct_data = None


class PixielDrainGirlBabyBoom(StatesGroup):
    pd = State()
    pd_data = None


class AdminStGroup(StatesGroup):
    on = State()


class AbracadabraStGroup(StatesGroup):
    on = State()